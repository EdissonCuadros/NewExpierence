package com.newexperience.pruebas.stepdefinitions;

import java.util.List;

import com.newexperience.pruebas.models.Usuario;
import com.newexperience.pruebas.steps.LoginSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class LoginStepDefinitions {

	@Steps
	LoginSteps loginSteps;
	
	
	@Given("^Ingrese al portal de NewExperience$")
	public void ingreseAlPortalDeNewExperience() {
		//Se abre el navegador en el portal requerido
	    loginSteps.abrirNewExperience();
	    //loginSteps.clickSignInHome();
	}

	@When("^Ingrese las credenciales$")
	public void ingreseLasCredenciales(List<Usuario> listaUsuario) {
		//Se ingresan las credenciales suministradas en la tabla del feature
		loginSteps.escribirUsuario(listaUsuario.get(0).getUsuario());
		loginSteps.escribirClave(listaUsuario.get(0).getClave());
		loginSteps.clickSignIn();
	    
	}

	@Then("^Validar el boton Sign Out$")
	public void validarElBotonSignOut() {
		//Se valida que al ingresar exitosamente aparezca el boton de Sign out
	    loginSteps.validarBtnSignOut();
	}
	
}
