package com.newexperience.pruebas.runners;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity; 

//Este es el RUNNER que ejecuta el caso de prueba de Login

@RunWith(CucumberWithSerenity.class) 
@CucumberOptions(features="src/test/resources/com/newexperience/pruebas/features/Login.feature",
glue="com.newexperience.pruebas.stepdefinitions",
snippets=SnippetType.CAMELCASE,
monochrome = true)

public class LoginRunner {

}


