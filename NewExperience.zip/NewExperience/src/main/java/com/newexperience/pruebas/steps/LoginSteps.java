package com.newexperience.pruebas.steps;



import com.newexperience.pruebas.pages.LoginPageObject;

import net.thucydides.core.annotations.Step;

public class LoginSteps {
	
	LoginPageObject loginPOM = new LoginPageObject();
	
	@Step
	public void abrirNewExperience() {
		loginPOM.open();
	}
	
	public void clickSignInHome() {
		loginPOM.clickSignInHome();
	}
	
	public void escribirUsuario(String usuario) {
		loginPOM.escribirUsuario(usuario);
	}

	public void escribirClave(String clave) {
		loginPOM.escribirClave(clave);
	}

	public void clickSignIn() {
		loginPOM.clickSignIn();
	}

	public void validarBtnSignOut() {
		loginPOM.validarBtnSignOut();
	}
	

}
