package com.newexperience.pruebas.pages;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://automationpractice.com/index.php?controller=authentication&back=my-account")
public class LoginPageObject extends PageObject {

	
	//Se realiza el mapeo de los objetos con los cuales se van a interactuar
	By btnSignInHome = By.xpath("//a[contains(text(),'Sign in')]");
	By txtUserName = By.name("email");
	By txtPassword = By.name("passwd");
	By btnSignIn = By.name("SubmitLogin");
	By btnSignOut = By.xpath("//a[contains(text(),'Sign out')]");

	public void clickSignInHome() {
		getDriver().findElement(btnSignInHome).click();
	}
	
	public void escribirUsuario(String usuario) {
		getDriver().findElement(txtUserName).sendKeys(usuario);
	}

	public void escribirClave(String clave) {
		getDriver().findElement(txtPassword).sendKeys(clave);
	}

	public void clickSignIn() {
		getDriver().findElement(btnSignIn).click();
	}

	public void validarBtnSignOut() {
		assertThat(getDriver().findElement(btnSignOut).isDisplayed(), Matchers.is(true));
		//getDriver().findElement(btnSignOut).click();
	}

}
